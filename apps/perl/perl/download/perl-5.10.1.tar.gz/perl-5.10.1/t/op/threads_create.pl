threads->create( sub { } )->join;
"ok\n";
