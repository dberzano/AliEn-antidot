/* Declarations which would have been found in <arpa/inet.h> */
/* On Plan 9, these are found in <netinet/in.h> */

/* extern unsigned long inet_addr(const char *); */
/* extern char *inet_ntoa(struct in_addr); */

#include <netinet/in.h>
